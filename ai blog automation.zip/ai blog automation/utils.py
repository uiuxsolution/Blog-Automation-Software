import logging
import re
from urllib.parse import urlparse

def setup_logging():
    """Set up logging configuration.

    Returns:
        logging.Logger: Configured logger instance
    """
    # Create logger
    logger = logging.getLogger('ai_blog_automation')
    logger.setLevel(logging.INFO)

    # Create console handler and set level to info
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)

    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Add handler to logger
    logger.addHandler(handler)

    return logger

def validate_inputs(tool_name: str, website_url: str) -> bool:
    """Validate command line inputs.

    Args:
        tool_name (str): Name of the AI tool
        website_url (str): Official website URL of the AI tool

    Returns:
        bool: True if inputs are valid, False otherwise
    """
    # Validate tool name
    if not tool_name or not isinstance(tool_name, str):
        return False
    
    # Basic tool name validation (alphanumeric with spaces)
    if not re.match(r'^[\w\s-]+$', tool_name):
        return False

    # Validate website URL
    if not website_url or not isinstance(website_url, str):
        return False

    # Parse URL and check if it's valid
    try:
        result = urlparse(website_url)
        return all([result.scheme, result.netloc])
    except:
        return False