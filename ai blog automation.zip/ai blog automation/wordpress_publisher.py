import os
from typing import Dict
from wordpress_xmlrpc import Client, WordPressPost
from wordpress_xmlrpc.methods.posts import NewPost
from tqdm import tqdm

class WordPressPublisher:
    def __init__(self):
        self.client = Client(
            os.getenv('WP_URL'),
            os.getenv('WP_USERNAME'),
            os.getenv('WP_PASSWORD')
        )

    def publish(self, blog_content: Dict[str, str]) -> str:
        """Publish the generated blog content to WordPress.

        Args:
            blog_content (Dict[str, str]): Generated blog content and metadata

        Returns:
            str: URL of the published blog post
        """
        try:
            # Create a new WordPress post
            post = WordPressPost()

            # Set post title
            post.title = blog_content['title']

            # Set post content with embedded YouTube video
            content = blog_content['content']
            if blog_content['youtube_embed']:
                youtube_embed = f'<iframe width="560" height="315" src="{blog_content["youtube_embed"]}" frameborder="0" allowfullscreen></iframe>'
                content = content + '\n\n' + youtube_embed

            post.content = content

            # Set post metadata
            post.post_status = 'publish'
            post.terms_names = {
                'post_tag': blog_content['keywords']['main_keywords'] + 
                           blog_content['keywords']['long_tail_keywords']
            }

            # Set SEO metadata (assuming Yoast SEO plugin)
            post.custom_fields = [
                {
                    'key': '_yoast_wpseo_metadesc',
                    'value': blog_content['meta_description']
                },
                {
                    'key': '_yoast_wpseo_focuskw',
                    'value': blog_content['keywords']['main_keywords'][0]
                }
            ]

            # Publish the post
            post_id = self.client.call(NewPost(post))

            # Get the post URL
            post_url = f"{os.getenv('WP_URL')}/p/{post_id}"

            return post_url

        except Exception as e:
            print(f"Error publishing to WordPress: {str(e)}")
            return ''