import os
from typing import Dict, List
from bs4 import BeautifulSoup
import requests
from googleapiclient.discovery import build
from tqdm import tqdm

class DataCollector:
    def __init__(self):
        self.youtube = build('youtube', 'v3', developerKey=os.getenv('GOOGLE_API_KEY'))

    def collect_website_data(self, website_url: str) -> Dict[str, str]:
        """Scrape relevant data from the AI tool's official website.

        Args:
            website_url (str): URL of the AI tool's official website

        Returns:
            Dict[str, str]: Dictionary containing website data
        """
        try:
            response = requests.get(website_url)
            soup = BeautifulSoup(response.text, 'html.parser')

            # Extract relevant information
            data = {
                'title': self._extract_title(soup),
                'description': self._extract_meta_description(soup),
                'features': self._extract_features(soup),
                'pricing': self._extract_pricing(soup),
                'docs_url': self._find_docs_url(website_url, soup),
                'blog_url': self._find_blog_url(website_url, soup)
            }

            return data

        except Exception as e:
            print(f"Error collecting website data: {str(e)}")
            return {}

    def collect_youtube_tutorials(self, tool_name: str) -> List[Dict[str, str]]:
        """Search and collect relevant YouTube tutorials about the AI tool.

        Args:
            tool_name (str): Name of the AI tool

        Returns:
            List[Dict[str, str]]: List of YouTube video data
        """
        try:
            # Search for tutorials
            search_query = f"{tool_name} tutorial OR review"
            search_response = self.youtube.search().list(
                q=search_query,
                part='snippet',
                type='video',
                maxResults=5,
                order='relevance'
            ).execute()

            # Process video data
            videos = []
            for item in search_response['items']:
                video_data = {
                    'title': item['snippet']['title'],
                    'description': item['snippet']['description'],
                    'video_id': item['id']['videoId'],
                    'thumbnail_url': item['snippet']['thumbnails']['high']['url'],
                    'embed_url': f"https://www.youtube.com/embed/{item['id']['videoId']}"
                }
                videos.append(video_data)

            return videos

        except Exception as e:
            print(f"Error collecting YouTube data: {str(e)}")
            return []

    def _extract_title(self, soup: BeautifulSoup) -> str:
        """Extract the main title from the website."""
        title_tag = soup.find('title')
        return title_tag.text.strip() if title_tag else ''

    def _extract_meta_description(self, soup: BeautifulSoup) -> str:
        """Extract meta description from the website."""
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        return meta_desc.get('content', '').strip() if meta_desc else ''

    def _extract_features(self, soup: BeautifulSoup) -> List[str]:
        """Extract feature list from the website."""
        features = []
        # This is a simplified version. In practice, you'd want to add
        # more sophisticated feature extraction logic based on the website structure
        feature_sections = soup.find_all(['section', 'div'], class_=lambda x: x and 'feature' in x.lower())
        for section in feature_sections:
            features.extend([item.text.strip() for item in section.find_all(['h2', 'h3', 'h4'])])
        return features

    def _extract_pricing(self, soup: BeautifulSoup) -> List[Dict[str, str]]:
        """Extract pricing information from the website."""
        pricing = []
        # This is a simplified version. In practice, you'd want to add
        # more sophisticated pricing extraction logic based on the website structure
        pricing_sections = soup.find_all(['section', 'div'], class_=lambda x: x and 'price' in x.lower())
        for section in pricing_sections:
            plan = {
                'name': section.find(['h2', 'h3', 'h4']).text.strip() if section.find(['h2', 'h3', 'h4']) else '',
                'price': section.find(class_=lambda x: x and 'price' in x.lower()).text.strip() if section.find(class_=lambda x: x and 'price' in x.lower()) else ''
            }
            pricing.append(plan)
        return pricing

    def _find_docs_url(self, base_url: str, soup: BeautifulSoup) -> str:
        """Find the documentation URL from the website."""
        docs_links = soup.find_all('a', href=lambda x: x and ('doc' in x.lower() or 'docs' in x.lower()))
        if docs_links:
            href = docs_links[0].get('href')
            return self._make_absolute_url(base_url, href)
        return ''

    def _find_blog_url(self, base_url: str, soup: BeautifulSoup) -> str:
        """Find the blog URL from the website."""
        blog_links = soup.find_all('a', href=lambda x: x and 'blog' in x.lower())
        if blog_links:
            href = blog_links[0].get('href')
            return self._make_absolute_url(base_url, href)
        return ''

    def _make_absolute_url(self, base_url: str, href: str) -> str:
        """Convert relative URLs to absolute URLs."""
        if href.startswith('http'):
            return href
        elif href.startswith('/'):
            return f"{base_url.rstrip('/')}{href}"
        else:
            return f"{base_url.rstrip('/')}/{href}"