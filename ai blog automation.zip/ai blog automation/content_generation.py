import os
from typing import Dict, List
import google.generativeai as genai
from tqdm import tqdm

class ContentGenerator:
    def __init__(self):
        genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
        self.model = genai.GenerativeModel('gemini-pro')
        self.generation_config = {
            'temperature': 0.7,
            'top_p': 0.8,
            'top_k': 40
        }

    def generate(self, tool_name: str, keywords: Dict[str, List[str]], 
                website_data: Dict[str, str], youtube_data: List[Dict[str, str]]) -> Dict[str, str]:
        """Generate SEO-optimized blog content using Google's Gemini API.

        Args:
            tool_name (str): Name of the AI tool
            keywords (Dict[str, List[str]]): Keywords from Perplexity AI
            website_data (Dict[str, str]): Data scraped from tool's website
            youtube_data (List[Dict[str, str]]): YouTube tutorial data

        Returns:
            Dict[str, str]: Generated blog content with metadata
        """
        try:
            # Build context and generate blog content with Gemini
            context = self._build_context(tool_name, keywords, website_data, youtube_data)
            blog_content = self._generate_blog(tool_name, keywords, context, youtube_data)

            return blog_content

        except Exception as e:
            print(f"Error generating content: {str(e)}")
            return {}

    def _build_context(self, tool_name: str, keywords: Dict[str, List[str]], 
                      website_data: Dict[str, str], youtube_data: List[Dict[str, str]]) -> str:
        """Build context document for NotebookLM analysis."""
        context = f"""
        Tool Name: {tool_name}

        Keywords:
        Main Keywords: {', '.join(keywords['main_keywords'])}
        Long-tail Keywords: {', '.join(keywords['long_tail_keywords'])}
        Competitor Keywords: {', '.join(keywords['competitor_keywords'])}
        Use Case Keywords: {', '.join(keywords['use_case_keywords'])}

        Website Data:
        Title: {website_data.get('title', '')}
        Description: {website_data.get('description', '')}
        Features: {', '.join(website_data.get('features', []))}
        Pricing: {str(website_data.get('pricing', []))}
        Documentation: {website_data.get('docs_url', '')}
        Blog: {website_data.get('blog_url', '')}

        YouTube Tutorials:
        {self._format_youtube_data(youtube_data)}
        """
        return context

    def _format_youtube_data(self, youtube_data: List[Dict[str, str]]) -> str:
        """Format YouTube data for context building."""
        formatted_data = []
        for video in youtube_data:
            formatted_data.append(
                f"Title: {video['title']}\n"
                f"Description: {video['description']}\n"
                f"URL: https://www.youtube.com/watch?v={video['video_id']}"
            )
        return '\n\n'.join(formatted_data)

    def _generate_blog(self, tool_name: str, keywords: Dict[str, List[str]], 
                      context: str, youtube_data: List[Dict[str, str]]) -> Dict[str, str]:
        """Generate blog content using Gemini API."""
        # Prepare the prompt for Gemini
        prompt = f"""
        Using the following context about {tool_name}, create a comprehensive, 
        SEO-optimized blog post that includes:

        1. An engaging title using main keywords
        2. Meta description optimized for SEO
        3. Introduction with key benefits
        4. Detailed features and use cases
        5. Pricing information
        6. Comparison with competitors
        7. Step-by-step tutorial section
        8. Embedded YouTube tutorial
        9. Conclusion with call-to-action

        Context:
        {context}

        Format the blog post in WordPress-ready HTML with proper headings, 
        paragraphs, and formatting. Include relevant keywords naturally throughout the content.
        """

        # Generate blog content with Gemini
        response = self.model.generate_content(
            prompt,
            generation_config=self.generation_config
        )

        # Extract and structure the generated content
        blog_content = {
            'title': self._extract_title(response.text),
            'meta_description': self._extract_meta_description(response.text),
            'content': response.text,
            'keywords': keywords,
            'youtube_embed': youtube_data[0]['video_id'] if youtube_data else ''
        }

        return blog_content

    def _extract_title(self, content: str) -> str:
        """Extract title from generated content."""
        lines = content.split('\n')
        for line in lines:
            line = line.strip()
            if line.startswith('<h1>') or line.startswith('#'):
                return line.replace('<h1>', '').replace('</h1>', '').replace('#', '').strip()
            elif 'title:' in line.lower():
                return line.split(':', 1)[1].strip()
        return ''

    def _extract_meta_description(self, content: str) -> str:
        """Extract meta description from generated content."""
        lines = content.split('\n')
        for i, line in enumerate(lines):
            line = line.strip().lower()
            if 'meta description:' in line or 'meta description' in line:
                if i + 1 < len(lines):
                    next_line = lines[i + 1].strip()
                    if next_line and not next_line.startswith('#') and not next_line.startswith('<h'):
                        return next_line
                if ':' in line:
                    return line.split(':', 1)[1].strip()
        return ''

    def _extract_content_sections(self, content: str) -> Dict[str, str]:
        """Extract different sections of the blog content."""
        sections = {
            'introduction': '',
            'features': '',
            'use_cases': '',
            'pricing': '',
            'competitors': '',
            'tutorial': '',
            'conclusion': ''
        }
        
        current_section = ''
        section_content = ''
        lines = content.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # Check if line is a header
            is_header = line.startswith('#') or line.startswith('<h')
            lower_line = line.lower()
            
            # Save accumulated content when encountering a new section
            if is_header:
                if current_section and current_section in sections:
                    sections[current_section] = section_content.strip()
                section_content = ''
                
                # Identify new section
                if 'introduction' in lower_line or 'overview' in lower_line:
                    current_section = 'introduction'
                elif 'feature' in lower_line:
                    current_section = 'features'
                elif 'use case' in lower_line or 'usage' in lower_line:
                    current_section = 'use_cases'
                elif 'pricing' in lower_line or 'cost' in lower_line:
                    current_section = 'pricing'
                elif 'competitor' in lower_line or 'comparison' in lower_line:
                    current_section = 'competitors'
                elif 'tutorial' in lower_line or 'guide' in lower_line or 'how to' in lower_line:
                    current_section = 'tutorial'
                elif 'conclusion' in lower_line:
                    current_section = 'conclusion'
            elif current_section and current_section in sections:
                section_content += line + '\n'
        
        # Save the last section's content
        if current_section and current_section in sections:
            sections[current_section] = section_content.strip()
                
        return sections
                
        return sections

    def _build_prompt(self, tool_name: str, context: str) -> str:
        """Build the prompt for Gemini API."""
        return f"""
        Using the following context about {tool_name}, create a comprehensive, 
        SEO-optimized blog post that includes:

        1. An engaging title using main keywords
        2. Meta description optimized for SEO
        3. Introduction with key benefits
        4. Detailed features and use cases
        5. Pricing information
        6. Comparison with competitors
        7. Step-by-step tutorial section
        8. Embedded YouTube tutorial
        9. Conclusion with call-to-action

        Context:
        {context}

        Format the blog post in WordPress-ready HTML with proper headings (h1, h2), 
        paragraphs, and formatting. Include relevant keywords naturally throughout the content.
        Make sure each section is clearly marked with appropriate headings.
        """

    def _generate_blog(self, tool_name: str, keywords: Dict[str, List[str]], 
                      context: str, youtube_data: List[Dict[str, str]]) -> Dict[str, str]:
        """Generate blog content using Gemini API."""
        # Generate content with Gemini
        response = self.model.generate_content(
            self._build_prompt(tool_name, context),
            generation_config=self.generation_config
        )

        # Extract sections
        sections = self._extract_content_sections(response.text)
        
        # Structure the blog content
        blog_content = {
            'title': self._extract_title(response.text),
            'meta_description': self._extract_meta_description(response.text),
            'content': response.text,
            'introduction': sections['introduction'],
            'features': sections['features'],
            'use_cases': sections['use_cases'],
            'pricing': sections['pricing'],
            'competitors': sections['competitors'],
            'tutorial': sections['tutorial'],
            'conclusion': sections['conclusion'],
            'keywords': keywords,
            'youtube_embed': youtube_data[0]['video_id'] if youtube_data else ''
        }

        return blog_content