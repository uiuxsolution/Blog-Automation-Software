import os
from typing import List, Dict
import google.generativeai as genai
from tqdm import tqdm

class PerplexityKeywordResearch:
    def __init__(self):
        genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
        self.model = genai.GenerativeModel('gemini-pro')
        self.generation_config = {
            'temperature': 0.7,
            'top_p': 0.8,
            'top_k': 40
        }

    def research(self, tool_name: str) -> Dict[str, List[str]]:
        """Perform keyword research for the given AI tool using Gemini API.

        Args:
            tool_name (str): Name of the AI tool to research

        Returns:
            Dict[str, List[str]]: Dictionary containing different categories of keywords
        """
        # Prepare the prompt for Gemini
        prompt = f"""
        Please analyze the AI tool '{tool_name}' and provide:
        1. Top 10 most searched keywords related to this tool
        2. Top 10 long-tail keywords with good search potential
        3. Top 5 competitor comparison keywords
        4. Top 5 use case specific keywords
        Format the response as a structured list.
        """

        # Query Gemini API
        response = self.model.generate_content(
            prompt,
            generation_config=self.generation_config
        )
        
        # Process and structure the keywords
        keywords = {
            'main_keywords': [],
            'long_tail_keywords': [],
            'competitor_keywords': [],
            'use_case_keywords': []
        }

        # Parse the response and extract keywords
        # Note: This is a simplified version. In practice, you'd want to add
        # more robust parsing logic based on Perplexity AI's response format
        try:
            lines = response.text.split('\n')
            current_category = None
            
            for line in lines:
                line = line.strip()
                if 'most searched keywords' in line.lower():
                    current_category = 'main_keywords'
                elif 'long-tail keywords' in line.lower():
                    current_category = 'long_tail_keywords'
                elif 'competitor comparison' in line.lower():
                    current_category = 'competitor_keywords'
                elif 'use case specific' in line.lower():
                    current_category = 'use_case_keywords'
                elif line.startswith('- ') and current_category:
                    keyword = line[2:].strip()
                    keywords[current_category].append(keyword)

        except Exception as e:
            print(f"Error parsing Perplexity AI response: {str(e)}")
            # Return empty lists if parsing fails
            return keywords

        return keywords

    def extract_google_suggestions(self, tool_name: str) -> List[str]:
        """Extract additional keywords from Google search suggestions.

        Args:
            tool_name (str): Name of the AI tool

        Returns:
            List[str]: List of additional keywords from Google suggestions
        """
        # This would typically involve scraping Google's autocomplete API
        # or using a service like SerpAPI (not implemented in this example)
        pass