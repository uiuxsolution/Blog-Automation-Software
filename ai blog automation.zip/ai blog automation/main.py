import argparse
import os
from dotenv import load_dotenv
from tqdm import tqdm

# Import our modules
from keyword_research import PerplexityKeywordResearch
from data_collection import DataCollector
from content_generation import ContentGenerator
from airtable_publisher import AirtablePublisher
from utils import setup_logging, validate_inputs

# Load environment variables
load_dotenv()

def parse_arguments():
    parser = argparse.ArgumentParser(description='AI Blog Automation Tool')
    parser.add_argument('--tool-name', required=True, help='Name of the AI tool to blog about')
    parser.add_argument('--website-url', required=True, help='Official website URL of the AI tool')
    return parser.parse_args()

def main():
    # Set up logging
    logger = setup_logging()
    logger.info('Starting AI blog automation workflow')

    # Parse command line arguments
    args = parse_arguments()
    
    # Validate inputs
    if not validate_inputs(args.tool_name, args.website_url):
        logger.error('Invalid inputs provided')
        return

    try:
        # Step 1: Keyword Research
        logger.info('Starting keyword research...')
        keyword_researcher = PerplexityKeywordResearch()
        keywords = keyword_researcher.research(args.tool_name)

        # Step 2: Data Collection
        logger.info('Collecting data...')
        data_collector = DataCollector()
        website_data = data_collector.collect_website_data(args.website_url)
        youtube_data = data_collector.collect_youtube_tutorials(args.tool_name)

        # Step 3: Content Generation
        logger.info('Generating content...')
        content_generator = ContentGenerator()
        blog_content = content_generator.generate(
            tool_name=args.tool_name,
            keywords=keywords,
            website_data=website_data,
            youtube_data=youtube_data
        )

        # Step 4: Save to Airtable
        logger.info('Saving to Airtable...')
        airtable_publisher = AirtablePublisher()
        record_id = airtable_publisher.save(blog_content)

        if record_id:
            logger.info(f'Blog content saved successfully to Airtable with record ID: {record_id}')
        else:
            logger.error('Failed to save blog content to Airtable')

    except Exception as e:
        logger.error(f'An error occurred: {str(e)}')
        raise

if __name__ == '__main__':
    main()