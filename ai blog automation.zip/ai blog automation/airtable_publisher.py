import os
from typing import Dict
from airtable import Airtable
from tqdm import tqdm

class AirtablePublisher:
    def __init__(self):
        self.base_id = os.getenv('AIRTABLE_BASE_ID')
        self.table_name = os.getenv('AIRTABLE_TABLE_NAME')
        self.api_key = os.getenv('AIRTABLE_API_KEY')
        self.airtable = Airtable(self.base_id, self.table_name, self.api_key)

    def save(self, blog_content: Dict[str, str]) -> str:
        """Save the generated blog content to Airtable.

        Args:
            blog_content (Dict[str, str]): Generated blog content and metadata

        Returns:
            str: Record ID of the created Airtable record
        """
        try:
            # Prepare record data with structured content
            record = {
                'Title': blog_content['title'],
                'Content': (
                    f"<h1>{blog_content['title']}</h1>\n\n"
                    f"<h2>Introduction</h2>\n{blog_content['introduction']}\n\n"
                    f"<h2>Features</h2>\n{blog_content['features']}\n\n"
                    f"<h2>Use Cases</h2>\n{blog_content['use_cases']}\n\n"
                    f"<h2>Pricing</h2>\n{blog_content['pricing']}\n\n"
                    f"<h2>Competitor Analysis</h2>\n{blog_content['competitors']}\n\n"
                    f"<h2>Tutorial</h2>\n{blog_content['tutorial']}\n\n"
                    f"<h2>Conclusion</h2>\n{blog_content['conclusion']}"
                ),
                'Meta Description': blog_content['meta_description'],
                'Main Keywords': ', '.join(blog_content['keywords']['main_keywords']),
                'Long Tail Keywords': ', '.join(blog_content['keywords']['long_tail_keywords']),
                'Competitor Keywords': ', '.join(blog_content['keywords']['competitor_keywords']),
                'Use Case Keywords': ', '.join(blog_content['keywords']['use_case_keywords']),
                'YouTube Embed': f"https://www.youtube.com/watch?v={blog_content['youtube_embed']}" if blog_content['youtube_embed'] else ''
            }

            # Insert record into Airtable
            result = self.airtable.insert(record)

            return result['id']

        except Exception as e:
            print(f"Error saving to Airtable: {str(e)}")
            return ''